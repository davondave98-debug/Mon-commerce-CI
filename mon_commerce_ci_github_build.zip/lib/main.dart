import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/models.dart';
import 'services/database.dart';
import 'services/voice.dart';

void main() => runApp(const MonCommerceApp());

class MonCommerceApp extends StatelessWidget {
  const MonCommerceApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false, title:'Mon Commerce CI',
    theme: ThemeData(useMaterial3:true, colorSchemeSeed:Colors.indigo),
    home: const PinGate());
}

class PinGate extends StatefulWidget { const PinGate({super.key}); @override State<PinGate> createState()=>_PinGateState(); }
class _PinGateState extends State<PinGate>{
  final pin=TextEditingController();
  bool hasPin=false, loading=true;
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); setState(()=>{hasPin=p.getString('pin')!=null,loading=false});}
  Future<void> _go() async {
    final p=await SharedPreferences.getInstance();
    if(hasPin){if(pin.text==p.getString('pin')) Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const Home()));}
    else {if(pin.text.length>=4){await p.setString('pin',pin.text);Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const Home()));}}
  }
  @override Widget build(BuildContext c){ if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
      const Icon(Icons.storefront,size:64),const SizedBox(height:12),const Text('Mon Commerce CI',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),Text(hasPin?'Entre ton code PIN':'Crée un code PIN de 4 chiffres minimum'),
      const SizedBox(height:18),TextField(controller:pin,obscureText:true,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Code PIN',border:OutlineInputBorder())),
      const SizedBox(height:14),FilledButton(onPressed:_go,child:Text(hasPin?'Ouvrir':'Créer'))]))));}
}

class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState()=>_HomeState(); }
class _HomeState extends State<Home>{
  int tab=0; final db=AppDb.instance;
  final money=NumberFormat.currency(locale:'fr_FR',symbol:'F',decimalDigits:0);
  @override Widget build(BuildContext c){ final pages=[Dashboard(db:db,money:money),ProductsPage(db:db),SalesPage(db:db),ExpensesPage(db:db),DebtsPage(db:db)];
    return Scaffold(appBar:AppBar(title:const Text('Mon Commerce CI')),body:pages[tab],
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const[
        NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Accueil'),
        NavigationDestination(icon:Icon(Icons.inventory_2_outlined),selectedIcon:Icon(Icons.inventory_2),label:'Stock'),
        NavigationDestination(icon:Icon(Icons.point_of_sale_outlined),selectedIcon:Icon(Icons.point_of_sale),label:'Ventes'),
        NavigationDestination(icon:Icon(Icons.payments_outlined),selectedIcon:Icon(Icons.payments),label:'Dépenses'),
        NavigationDestination(icon:Icon(Icons.credit_card_outlined),selectedIcon:Icon(Icons.credit_card),label:'Dettes'),
      ]));}
}

class Dashboard extends StatefulWidget{final AppDb db;final NumberFormat money;const Dashboard({super.key,required this.db,required this.money});@override State<Dashboard> createState()=>_DashboardState();}
class _DashboardState extends State<Dashboard>{
  double s=0,p=0,e=0; @override void initState(){super.initState();_load();}
  Future<void> _load()async{setState((){});s=await widget.db.salesTotal();p=await widget.db.grossProfit();e=await widget.db.expensesTotal();setState((){});}
  @override Widget build(BuildContext c)=>RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Aujourd’hui / total local',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:12),
    Row(children:[Expanded(child:StatCard('Ventes',widget.money.format(s))),const SizedBox(width:10),Expanded(child:StatCard('Bénéfice brut',widget.money.format(p)))]),
    const SizedBox(height:10),StatCard('Dépenses',widget.money.format(e)),const SizedBox(height:10),StatCard('Bénéfice après dépenses',widget.money.format(p-e)),
    const SizedBox(height:20),const Text('Conseil',style:TextStyle(fontWeight:FontWeight.bold)),const Text('Enregistre chaque vente et chaque dépense pour connaître ton bénéfice réel.')]));
}
class StatCard extends StatelessWidget{final String a,b;const StatCard(this.a,this.b,{super.key});@override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a),const SizedBox(height:5),Text(b,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold))])));}

class ProductsPage extends StatefulWidget{final AppDb db;const ProductsPage({super.key,required this.db});@override State<ProductsPage> createState()=>_ProductsPageState();}
class _ProductsPageState extends State<ProductsPage>{List<Product> items=[];String q='';@override void initState(){super.initState();load();}Future<void>load()async{items=await widget.db.products(q);setState((){});}
Future<void>add()async{final n=TextEditingController(),a=TextEditingController(),v=TextEditingController(),s=TextEditingController(text:'0');final ok=await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Ajouter un produit'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Nom')),TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Prix achat')),TextField(controller:v,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Prix vente')),TextField(controller:s,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Stock initial'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Ajouter'))]));if(ok==true){await widget.db.addProduct(Product(name:n.text,purchasePrice:double.tryParse(a.text)??0,salePrice:double.tryParse(v.text)??0,stock:int.tryParse(s.text)??0));load();}}
@override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:TextField(onChanged:(x){q=x;load();},decoration:const InputDecoration(prefixIcon:Icon(Icons.search),labelText:'Rechercher',border:OutlineInputBorder()))),Expanded(child:ListView.builder(itemCount:items.length,itemBuilder:(_,i){final p=items[i];return ListTile(title:Text(p.name),subtitle:Text('Achat ${p.purchasePrice.toStringAsFixed(0)} F • Vente ${p.salePrice.toStringAsFixed(0)} F'),trailing:Text('${p.stock}',style:TextStyle(fontWeight:FontWeight.bold,color:p.stock<=p.lowStock?Colors.red:null)));}))],);}

class SalesPage extends StatefulWidget{final AppDb db;const SalesPage({super.key,required this.db});@override State<SalesPage> createState()=>_SalesPageState();}
class _SalesPageState extends State<SalesPage>{List<Product> products=[];final voice=VoiceService();String spoken='';@override void initState(){super.initState();load();}Future<void>load()async{products=await widget.db.products();setState((){});}
Future<void>sell(Product p)async{final q=TextEditingController(text:'1');final ok=await showDialog(context:context,builder:(_)=>AlertDialog(title:Text('Vendre ${p.name}'),content:TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Quantité')),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Vendre'))]));if(ok==true){try{await widget.db.addSale(p,int.parse(q.text));load();if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Vente enregistrée')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}}}
Future<void>listen()async{await voice.listen((x){setState(()=>spoken=x);});}
@override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:Text(spoken.isEmpty?'Appuie sur le micro et dis par exemple : “Coca 500, 3”':'$spoken',style:const TextStyle(fontSize:15))),IconButton(onPressed:listen,icon:const Icon(Icons.mic))])),Expanded(child:ListView.builder(itemCount:products.length,itemBuilder:(_,i){final p=products[i];return ListTile(title:Text(p.name),subtitle:Text('Stock: ${p.stock} • ${p.salePrice.toStringAsFixed(0)} F'),trailing:FilledButton(onPressed:p.stock>0?()=>sell(p):null,child:const Text('Vendre')));}))]);}

class ExpensesPage extends StatefulWidget{final AppDb db;const ExpensesPage({super.key,required this.db});@override State<ExpensesPage> createState()=>_ExpensesPageState();}
class _ExpensesPageState extends State<ExpensesPage>{List<Map<String,Object?>> rows=[];@override void initState(){super.initState();load();}Future<void>load()async{rows=await widget.db.expenses();setState((){});}Future<void>add()async{final l=TextEditingController(),a=TextEditingController();final ok=await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Nouvelle dépense'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:l,decoration:const InputDecoration(labelText:'Description')),TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Montant'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Enregistrer'))]));if(ok==true){await widget.db.addExpense(Expense(label:l.text,amount:double.tryParse(a.text)??0,date:DateTime.now()));load();}}
@override Widget build(BuildContext c)=>Scaffold(body:ListView.builder(itemCount:rows.length,itemBuilder:(_,i)=>ListTile(title:Text(rows[i]['label'] as String),trailing:Text('${(rows[i]['amount'] as num).toStringAsFixed(0)} F')),),floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)));}

class DebtsPage extends StatefulWidget{final AppDb db;const DebtsPage({super.key,required this.db});@override State<DebtsPage> createState()=>_DebtsPageState();}
class _DebtsPageState extends State<DebtsPage>{List<Map<String,Object?>> rows=[];@override void initState(){super.initState();load();}Future<void>load()async{rows=await widget.db.debts();setState((){});}Future<void>add()async{final n=TextEditingController(),a=TextEditingController(),p=TextEditingController(text:'0');final ok=await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Nouvelle dette'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Client')),TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Montant')),TextField(controller:p,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Déjà payé'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Enregistrer'))]));if(ok==true){await widget.db.addDebt(Debt(customer:n.text,amount:double.tryParse(a.text)??0,paid:double.tryParse(p.text)??0,date:DateTime.now()));load();}}
@override Widget build(BuildContext c)=>Scaffold(body:ListView.builder(itemCount:rows.length,itemBuilder:(_,i){final r=rows[i];final left=(r['amount'] as num)-(r['paid'] as num);return ListTile(title:Text(r['customer'] as String),subtitle:Text('Reste: ${left.toStringAsFixed(0)} F'),trailing:Text('${(r['amount'] as num).toStringAsFixed(0)} F'));}),floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)));}}
