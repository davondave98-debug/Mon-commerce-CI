class Product {
  final int? id;
  final String name;
  final double purchasePrice;
  final double salePrice;
  final int stock;
  final int lowStock;

  Product({this.id, required this.name, required this.purchasePrice,
      required this.salePrice, required this.stock, this.lowStock = 5});

  Map<String, Object?> toMap() => {
    'id': id, 'name': name, 'purchase_price': purchasePrice,
    'sale_price': salePrice, 'stock': stock, 'low_stock': lowStock
  };

  factory Product.fromMap(Map<String,Object?> m) => Product(
    id: m['id'] as int?, name: m['name'] as String,
    purchasePrice: (m['purchase_price'] as num).toDouble(),
    salePrice: (m['sale_price'] as num).toDouble(),
    stock: (m['stock'] as num).toInt(),
    lowStock: (m['low_stock'] as num?)?.toInt() ?? 5);
}

class Sale {
  final int? id;
  final int productId;
  final String productName;
  final int qty;
  final double unitSale;
  final double unitPurchase;
  final DateTime date;

  Sale({this.id, required this.productId, required this.productName,
      required this.qty, required this.unitSale, required this.unitPurchase,
      required this.date});

  Map<String,Object?> toMap() => {
    'id': id, 'product_id': productId, 'product_name': productName,
    'qty': qty, 'unit_sale': unitSale, 'unit_purchase': unitPurchase,
    'date': date.toIso8601String()
  };
}

class Expense {
  final int? id;
  final String label;
  final double amount;
  final DateTime date;
  Expense({this.id, required this.label, required this.amount, required this.date});
  Map<String,Object?> toMap() => {'id':id,'label':label,'amount':amount,'date':date.toIso8601String()};
}

class Debt {
  final int? id;
  final String customer;
  final double amount;
  final double paid;
  final DateTime date;
  Debt({this.id,required this.customer,required this.amount,required this.paid,required this.date});
  Map<String,Object?> toMap() => {'id':id,'customer':customer,'amount':amount,'paid':paid,'date':date.toIso8601String()};
}
