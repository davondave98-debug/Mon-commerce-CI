import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final SpeechToText speech = SpeechToText();
  bool ready = false;

  Future<bool> init() async {
    ready = await speech.initialize();
    return ready;
  }

  Future<void> listen(void Function(String) onText) async {
    if (!ready) await init();
    if (!ready) return;
    await speech.listen(localeId: 'fr_FR', onResult: (r) => onText(r.recognizedWords));
  }

  Future<void> stop() => speech.stop();
}
