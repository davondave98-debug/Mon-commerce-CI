import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/models.dart';

class AppDb {
  static final AppDb instance = AppDb._();
  AppDb._();
  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await openDatabase(join(await getDatabasesPath(), 'mon_commerce_ci.db'),
      version: 1, onCreate: (db, v) async {
        await db.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,purchase_price REAL NOT NULL,sale_price REAL NOT NULL,stock INTEGER NOT NULL,low_stock INTEGER NOT NULL)');
        await db.execute('CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,product_name TEXT NOT NULL,qty INTEGER NOT NULL,unit_sale REAL NOT NULL,unit_purchase REAL NOT NULL,date TEXT NOT NULL)');
        await db.execute('CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,label TEXT NOT NULL,amount REAL NOT NULL,date TEXT NOT NULL)');
        await db.execute('CREATE TABLE debts(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT NOT NULL,amount REAL NOT NULL,paid REAL NOT NULL,date TEXT NOT NULL)');
      });
    return _db!;
  }

  Future<List<Product>> products([String q='']) async {
    final d=await db;
    final rows=await d.query('products', where:q.isEmpty?null:'name LIKE ?', whereArgs:q.isEmpty?null:['%$q%'], orderBy:'name');
    return rows.map(Product.fromMap).toList();
  }
  Future<int> addProduct(Product p) async => (await db).insert('products', p.toMap());
  Future<int> updateStock(int id,int stock) async => (await db).update('products',{'stock':stock},where:'id=?',whereArgs:[id]);
  Future<int> deleteProduct(int id) async => (await db).delete('products',where:'id=?',whereArgs:[id]);

  Future<void> addSale(Product p,int qty) async {
    final d=await db;
    if(qty<1 || p.id==null || qty>p.stock) throw Exception('Stock insuffisant');
    await d.transaction((tx) async {
      await tx.insert('sales', Sale(productId:p.id!,productName:p.name,qty:qty,unitSale:p.salePrice,unitPurchase:p.purchasePrice,date:DateTime.now()).toMap());
      await tx.update('products',{'stock':p.stock-qty},where:'id=?',whereArgs:[p.id]);
    });
  }
  Future<List<Map<String,Object?>>> recentSales() async => (await db).query('sales',orderBy:'id DESC',limit:30);
  Future<double> salesTotal() async { final r=await (await db).rawQuery('SELECT COALESCE(SUM(qty*unit_sale),0) t FROM sales'); return (r.first['t'] as num).toDouble(); }
  Future<double> grossProfit() async { final r=await (await db).rawQuery('SELECT COALESCE(SUM(qty*(unit_sale-unit_purchase)),0) t FROM sales'); return (r.first['t'] as num).toDouble(); }

  Future<int> addExpense(Expense e) async => (await db).insert('expenses',e.toMap());
  Future<double> expensesTotal() async { final r=await (await db).rawQuery('SELECT COALESCE(SUM(amount),0) t FROM expenses'); return (r.first['t'] as num).toDouble(); }
  Future<List<Map<String,Object?>>> expenses() async => (await db).query('expenses',orderBy:'id DESC',limit:50);

  Future<int> addDebt(Debt d) async => (await db).insert('debts',d.toMap());
  Future<List<Map<String,Object?>>> debts() async => (await db).query('debts',orderBy:'id DESC',limit:50);
}
