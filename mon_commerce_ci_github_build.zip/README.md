# Mon Commerce CI — V1

Application Flutter Android de gestion de commerce, conçue pour fonctionner principalement hors connexion.

Fonctions :
- produits et stock
- ventes
- bénéfice
- dépenses
- dettes clients
- tableau de bord
- recherche produit
- seuil de stock faible
- code PIN local
- commande vocale via le moteur de reconnaissance vocale Android disponible sur le téléphone

## Lancer
1. Installer Flutter + Android Studio.
2. `flutter pub get`
3. `flutter run`

## APK
`flutter build apk --release`

L'APK sera dans `build/app/outputs/flutter-apk/app-release.apk`.

### Vocal hors connexion
La fonction utilise le moteur Android disponible sur le téléphone. Pour une reconnaissance totalement hors ligne, le moteur et le pack de langue français du téléphone doivent eux-mêmes prendre en charge le mode hors connexion. L'application garde toujours une saisie manuelle de secours.
