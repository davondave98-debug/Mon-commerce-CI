# Permission vocale
Le plugin speech_to_text demande l'accès microphone sur Android. Ajoute la permission RECORD_AUDIO dans android/app/src/main/AndroidManifest.xml si elle n'est pas déjà ajoutée par le plugin.
Pour le hors-ligne, active un moteur/langue française hors connexion sur le téléphone si Android le propose.
