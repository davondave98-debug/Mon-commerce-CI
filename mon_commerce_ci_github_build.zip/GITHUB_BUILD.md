# Compilation automatique sur téléphone

1. Crée/connecte-toi à un compte GitHub.
2. Crée un nouveau dépôt, par exemple `mon-commerce-ci`.
3. Envoie tout le contenu de ce projet dans le dépôt.
4. Ouvre l'onglet **Actions** du dépôt.
5. Sélectionne **Build Mon Commerce CI APK**.
6. Appuie sur **Run workflow** si le dépôt est sur `main` ou `master`.
7. Attends la fin du build.
8. Dans le workflow terminé, ouvre **Artifacts** puis télécharge `mon-commerce-ci-apk`.
9. Le fichier téléchargé contient `app-release.apk`.

Le workflow installe Flutter et Java automatiquement et construit l'APK en mode release.

Important : la reconnaissance vocale hors ligne dépend du moteur vocal Android et du pack français installé sur le téléphone.
